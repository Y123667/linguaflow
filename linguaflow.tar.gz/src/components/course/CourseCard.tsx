import { motion } from 'framer-motion';
import { BookOpen, Clock, Star } from 'lucide-react';
import { Card } from '../common/Card';
import type { Course } from '../../types';

interface CourseCardProps {
  course: Course;
  onClick: () => void;
  progress?: number;
}

export function CourseCard({ course, onClick, progress = 0 }: CourseCardProps) {
  const languageFlags: Record<string, string> = {
    en: '🇬🇧',
    ja: '🇯🇵',
    ko: '🇰🇷',
  };

  const levelColors: Record<string, string> = {
    beginner: 'bg-secondary-100 text-secondary-700',
    intermediate: 'bg-accent-100 text-accent-700',
    advanced: 'bg-red-100 text-red-700',
  };

  const totalLessons = course.lessons.length;
  const completedLessons = Math.floor((progress / 100) * totalLessons);

  return (
    <motion.div
      whileHover={{ y: -4 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
    >
      <Card hover padding="none" className="overflow-hidden">
        <div className="relative h-36 overflow-hidden">
          <img
            src={course.thumbnail}
            alt={course.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-dark-900/60 to-transparent" />
          <div className="absolute top-3 left-3 flex items-center gap-2">
            <span className="text-2xl">{languageFlags[course.language]}</span>
            <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${levelColors[course.level]}`}>
              {course.level === 'beginner' ? '初级' : course.level === 'intermediate' ? '中级' : '高级'}
            </span>
          </div>
          <div className="absolute bottom-3 left-3 right-3">
            <h3 className="font-heading font-semibold text-white text-lg line-clamp-1">
              {course.title}
            </h3>
          </div>
        </div>

        <div className="p-4">
          <p className="text-dark-500 text-sm line-clamp-2 mb-3">{course.description}</p>

          <div className="flex items-center justify-between text-sm text-dark-400 mb-3">
            <div className="flex items-center gap-1">
              <BookOpen className="w-4 h-4" />
              <span>{totalLessons} 课时</span>
            </div>
            <div className="flex items-center gap-1">
              <Clock className="w-4 h-4" />
              <span>{course.lessons.reduce((sum, l) => sum + l.duration, 0)} 分钟</span>
            </div>
            <div className="flex items-center gap-1">
              <Star className="w-4 h-4 text-accent-500" />
              <span>{course.xpReward} XP</span>
            </div>
          </div>

          {progress > 0 && (
            <div className="space-y-1">
              <div className="h-2 bg-dark-100 rounded-full overflow-hidden">
                <motion.div
                  className="h-full gradient-primary rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: `${progress}%` }}
                  transition={{ duration: 0.5 }}
                />
              </div>
              <p className="text-xs text-dark-400">
                已完成 {completedLessons}/{totalLessons} 课时
              </p>
            </div>
          )}
        </div>
      </Card>
    </motion.div>
  );
}
