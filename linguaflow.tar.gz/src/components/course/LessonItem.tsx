import { motion } from 'framer-motion';
import { Play, CheckCircle, BookOpen, FileText, Mic, Headphones } from 'lucide-react';
import { clsx } from 'clsx';
import type { Lesson } from '../../types';

interface LessonItemProps {
  lesson: Lesson;
  index: number;
  isCompleted?: boolean;
  onClick: () => void;
}

const lessonTypeIcons = {
  vocabulary: BookOpen,
  grammar: FileText,
  speaking: Mic,
  listening: Headphones,
};

const lessonTypeColors = {
  vocabulary: 'bg-primary-100 text-primary-600',
  grammar: 'bg-secondary-100 text-secondary-600',
  speaking: 'bg-accent-100 text-accent-600',
  listening: 'bg-purple-100 text-purple-600',
};

const lessonTypeNames = {
  vocabulary: '单词',
  grammar: '语法',
  speaking: '口语',
  listening: '听力',
};

export function LessonItem({ lesson, index, isCompleted, onClick }: LessonItemProps) {
  const Icon = lessonTypeIcons[lesson.type];

  return (
    <motion.button
      onClick={onClick}
      whileHover={{ x: 4 }}
      whileTap={{ scale: 0.98 }}
      className={clsx(
        'w-full flex items-center gap-4 p-4 rounded-xl transition-all',
        isCompleted ? 'bg-secondary-50' : 'bg-white hover:bg-dark-50',
        'border border-dark-200 hover:border-primary-200'
      )}
    >
      <div className={clsx(
        'w-12 h-12 rounded-xl flex items-center justify-center',
        lessonTypeColors[lesson.type]
      )}>
        {isCompleted ? (
          <CheckCircle className="w-6 h-6" />
        ) : (
          <Icon className="w-6 h-6" />
        )}
      </div>

      <div className="flex-1 text-left">
        <div className="flex items-center gap-2">
          <span className="text-sm text-dark-400">第 {index + 1} 课</span>
          <span className={clsx(
            'px-2 py-0.5 rounded text-xs font-medium',
            lessonTypeColors[lesson.type]
          )}>
            {lessonTypeNames[lesson.type]}
          </span>
        </div>
        <h4 className="font-medium text-dark-800 mt-0.5">{lesson.title}</h4>
        <p className="text-sm text-dark-400 mt-0.5">{lesson.duration} 分钟</p>
      </div>

      <div className={clsx(
        'w-10 h-10 rounded-xl flex items-center justify-center',
        isCompleted ? 'bg-secondary-500 text-white' : 'bg-primary-500 text-white'
      )}>
        {isCompleted ? (
          <CheckCircle className="w-5 h-5" />
        ) : (
          <Play className="w-5 h-5 ml-0.5" />
        )}
      </div>
    </motion.button>
  );
}
